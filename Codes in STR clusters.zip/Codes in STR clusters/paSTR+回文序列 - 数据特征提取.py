import os
import re
import pandas as pd
from Bio import SeqIO
from tkinter import Tk, simpledialog, messagebox
from tkinter.filedialog import askdirectory
from tqdm import tqdm
import numpy as np

# 设置Tkinter不显示根窗口
Tk().withdraw()

# 弹出文件夹检索框
folder_path = askdirectory(title='Select Folder with FASTA files')

# 用户输入设置
min_palindrome_length = int(simpledialog.askstring("Input", "Set minimum palindrome total length (bp):"))
max_palindrome_length = int(simpledialog.askstring("Input", "Set maximum palindrome total length (bp):"))
min_motif_length = int(simpledialog.askstring("Input", "Set minimum motif length:"))
max_motif_length = int(simpledialog.askstring("Input", "Set maximum motif length:"))
min_repeats = int(simpledialog.askstring("Input", "Set minimum repeats:"))
max_repeats = int(simpledialog.askstring("Input", "Set maximum repeats:"))
delete_empty_pastr_rows = messagebox.askyesno("Input",
                                              "Do you want to delete sequences with no paSTRs from the results?")


# 定义回文序列查找函数
def reverse_complement(sequence):
    complement_dict = str.maketrans('ATCGN', 'TAGCN')
    return sequence.translate(complement_dict)[::-1]


def find_palindromes(sequence, min_length, max_length):
    results = []
    seq_length = len(sequence)
    rev_comp_sequence = reverse_complement(sequence)
    seen = {}

    for i in range(seq_length - min_length + 1):
        for j in range(min_length, min(max_length, seq_length - i) + 1):
            segment = sequence[i:i + j]
            if segment in seen:
                rev_comp_segment = seen[segment]
            else:
                rev_comp_segment = reverse_complement(segment)
                seen[segment] = rev_comp_segment

            if segment == rev_comp_segment and j % 2 == 0:  # 确保Palindrome长度为偶数
                results.append({
                    'Start': i + 1,
                    'End': i + j,
                    'Length': j,
                    'Palindrome': segment,
                    'GC Content (%)': (segment.count('G') + segment.count('C')) / j * 100,
                    'AT Content (%)': (segment.count('A') + segment.count('T')) / j * 100
                })
    return results


# 定义bSTR查找函数
def find_bstrs(sequence):
    bstrs = []
    for motif_length in range(min_motif_length, max_motif_length + 1):
        pattern = re.compile(r'((\w{%d})\2{%d,})' % (motif_length, min_repeats - 1))
        for match in pattern.finditer(sequence):
            motif = match.group(2)
            full_seq = match.group(1)
            start = match.start(1) + 1  # 修正STR Start数值
            end = match.end(1)
            repeats = len(full_seq) // len(motif)
            gc_content = (full_seq.count('G') + full_seq.count('C')) / len(full_seq) * 100
            at_content = (full_seq.count('A') + full_seq.count('T')) / len(full_seq) * 100
            if len(full_seq) >= min_palindrome_length and min_repeats <= repeats <= max_repeats:
                bstrs.append({
                    'Sequence': full_seq,
                    'STR Start': start,
                    'STR End': end,
                    'Motif Length': len(motif),
                    'Repeats': repeats,
                    'Total Length': len(full_seq),
                    'GC Content (%)': gc_content,
                    'AT Content (%)': at_content
                })
    return bstrs


# 计算bSTR的置信区间
def calculate_confidence_intervals(bstrs, sequence_length, num_bootstrap=1000, confidence_level=0.95):
    bstr_lengths = [bstr['Total Length'] for bstr in bstrs]
    if len(bstr_lengths) > 0:
        means = []
        for _ in range(num_bootstrap):
            sample = np.random.choice(bstr_lengths, size=len(bstr_lengths), replace=True)
            means.append(np.mean(sample))
        lower_bound = np.percentile(means, (1 - confidence_level) / 2 * 100)
        upper_bound = np.percentile(means, (1 + confidence_level) / 2 * 100)
        mean_length = np.mean(bstr_lengths)
    else:
        mean_length = 0
        upper_bound = 0
        lower_bound = 0
    return mean_length, upper_bound, lower_bound


# 处理所有FASTA文件
files = [f for f in os.listdir(folder_path) if f.endswith('.fas') or f.endswith('.fasta')]

for file in tqdm(files, desc="Processing files"):
    file_path = os.path.join(folder_path, file)
    palindrome_results = []
    pastr_results = []

    for record in SeqIO.parse(file_path, 'fasta'):
        sequence = str(record.seq).replace('-', '')  # 删除所有的gaps
        palindromes = find_palindromes(sequence, min_palindrome_length, max_palindrome_length)
        bstrs = find_bstrs(sequence)

        sequence_length = len(sequence)
        total_palindrome_length = sum(palindrome['Length'] for palindrome in palindromes)
        total_bstr_length = sum(bstr['Total Length'] for bstr in bstrs)
        pastrs = [bstr for bstr in bstrs if
                  any(bstr['Sequence'] == palindrome['Palindrome'] for palindrome in palindromes)]

        total_pastr_length = sum(pastr['Total Length'] for pastr in pastrs)

        # 统计每条序列的基本特征
        palindrome_features = {
            'Sequence ID': record.description,
            'Palindrome Count': len(palindromes),
            'Total Palindrome Length': np.mean(
                [palindrome['Length'] for palindrome in palindromes]) if palindromes else 0,
            'Average GC Content (%)': np.mean(
                [palindrome['GC Content (%)'] for palindrome in palindromes]) if palindromes else 0,
            'Average AT Content (%)': np.mean(
                [palindrome['AT Content (%)'] for palindrome in palindromes]) if palindromes else 0,
            'Palindrome Length Density (%)': (total_palindrome_length * 100) / sequence_length if sequence_length > 0 else 0,
            'Palindrome Count Density (%)': (len(palindromes) * 100) / sequence_length if sequence_length > 0 else 0
        }
        palindrome_results.append(palindrome_features)

        # 计算不同motif长度的paSTR占比
        motif_length_counts = {length: 0 for length in range(min_motif_length, max_motif_length + 1)}
        for pastr in pastrs:
            motif_length_counts[pastr['Motif Length']] += 1
        motif_length_proportions = {
            f'Motif Length Proportion_{length}': (count / len(pastrs)) * 100 if len(pastrs) > 0 else 0
            for length, count in motif_length_counts.items()}

        # 计算不同repeats大小的paSTR占比
        repeats_counts = {repeats: 0 for repeats in range(min_repeats, max_repeats + 1)}
        for pastr in pastrs:
            repeats_counts[pastr['Repeats']] += 1
        repeats_proportions = {f'Repeats Proportion_{repeats}': (count / len(pastrs)) * 100 if len(pastrs) > 0 else 0
                               for repeats, count in repeats_counts.items()}

        # 统计每条序列的paSTR特征
        pastr_features = {
            'Sequence ID': record.description,
            'paSTR Count': len(pastrs),
            'Average Motif Length': np.mean([pastr['Motif Length'] for pastr in pastrs]) if pastrs else 0,
            'Average Repeats': np.mean([pastr['Repeats'] for pastr in pastrs]) if pastrs else 0,
            'Total paSTR Length': np.mean([pastr['Total Length'] for pastr in pastrs]) if pastrs else 0,
            'Average GC Content (%)': np.mean([pastr['GC Content (%)'] for pastr in pastrs]) if pastrs else 0,
            'Average AT Content (%)': np.mean([pastr['AT Content (%)'] for pastr in pastrs]) if pastrs else 0,
            'paSTR Length Density (%)': (total_pastr_length * 100) / sequence_length if sequence_length > 0 else 0,
            # 这里修正为使用total_pastr_length
            'paSTR Count Density (units/bp)': (len(pastrs) * 100) / sequence_length if sequence_length > 0 else 0,
            'paSTR to Palindrome Ratio (%)': (len(pastrs) * 100) / len(palindromes) if len(palindromes) > 0 else 0
        }
        pastr_features.update(motif_length_proportions)
        pastr_features.update(repeats_proportions)
        pastr_results.append(pastr_features)


    # 计算整体特征的平均值和标准差
    def calculate_overall_stats(results, features):
        df = pd.DataFrame(results)
        # 添加所有缺失的列，初始化为0
        for feature in features:
            if feature not in df.columns:
                df[feature] = 0
        numeric_df = df[features].apply(pd.to_numeric, errors='coerce')  # 转换数值型特征
        means = numeric_df.mean().to_frame().transpose()
        stds = numeric_df.std().to_frame().transpose()
        means['Sequence ID'] = 'Avg'
        stds['Sequence ID'] = 'SD'
        overall_df = pd.concat([df, means, stds], ignore_index=True)
        overall_df = overall_df[['Sequence ID'] + features]
        return overall_df


    # 定义要计算的特征列
    palindrome_features = [
        'Palindrome Count', 'Total Palindrome Length', 'Average GC Content (%)', 'Average AT Content (%)',
        'Palindrome Length Density (%)', 'Palindrome Count Density (%)'
    ]

    pastr_features = [
        'paSTR Count', 'Average Motif Length', 'Average Repeats', 'Total paSTR Length', 'Average GC Content (%)',
        'Average AT Content (%)', 'paSTR Count Density (units/bp)', 'paSTR Length Density (%)',
        'paSTR to Palindrome Ratio (%)'
    ]

    motif_length_proportion_features = [f'Motif Length Proportion_{length}' for length in
                                        range(min_motif_length, max_motif_length + 1)]
    repeats_proportion_features = [f'Repeats Proportion_{repeats}' for repeats in range(min_repeats, max_repeats + 1)]

    # 计算并保存结果
    palindrome_df = calculate_overall_stats(palindrome_results, palindrome_features)
    pastr_df = pd.DataFrame(pastr_results)

    # 根据用户选择删除不存在paSTR的行
    if delete_empty_pastr_rows:
        pastr_df = pastr_df[pastr_df['paSTR Count'] > 0]

    # 计算paSTR结果的平均值和标准差
    pastr_stats_df = calculate_overall_stats(pastr_df.to_dict(orient='records'),
                                             pastr_features + motif_length_proportion_features + repeats_proportion_features)

    # 重新排序paSTR结果中的列，确保Motif Length Proportion和Repeats Proportion紧跟在Total paSTR Length之后
    pastr_stats_df = pastr_stats_df[
        ['Sequence ID', 'paSTR Count', 'Average Motif Length', 'Average Repeats', 'Total paSTR Length'] +
        motif_length_proportion_features + repeats_proportion_features +
        ['Average GC Content (%)', 'Average AT Content (%)', 'paSTR Length Density (%)',
         'paSTR Count Density (units/bp)', 'paSTR to Palindrome Ratio (%)']]

    file_basename = os.path.splitext(file)[0]
    palindrome_filename = f'Palindrome_data_features-{file_basename}.xlsx'
    pastr_filename = f'paSTR_data_features-{file_basename}.xlsx'

    palindrome_df.to_excel(palindrome_filename, index=False)
    pastr_stats_df.to_excel(pastr_filename, index=False)

print("Results saved to respective Excel files")
