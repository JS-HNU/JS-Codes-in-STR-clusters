import os
import re
from Bio import SeqIO
from tkinter import Tk, simpledialog
from tkinter.filedialog import askdirectory
from tqdm import tqdm
from Bio.SeqRecord import SeqRecord
from Bio.Seq import Seq

# 设置Tkinter不显示根窗口
Tk().withdraw()

# 弹出文件夹检索框
folder_path = askdirectory(title='Select Folder with FASTA files')

# 用户输入设置
min_bstr_length = int(simpledialog.askstring("Input", "Set minimum bSTR total length (bp):"))
min_motif_length = int(simpledialog.askstring("Input", "Set minimum motif length:"))
max_motif_length = int(simpledialog.askstring("Input", "Set maximum motif length:"))
min_repeats = int(simpledialog.askstring("Input", "Set minimum repeats:"))
max_repeats = int(simpledialog.askstring("Input", "Set maximum repeats:"))

# 定义bSTR查找函数
def find_bstrs(sequence):
    bstrs = []
    for motif_length in range(min_motif_length, max_motif_length + 1):
        pattern = re.compile(r'((\w{%d})\2{%d,})' % (motif_length, min_repeats - 1))
        for match in pattern.finditer(sequence):
            motif = match.group(2)
            full_seq = match.group(1)
            start = match.start(1) + 1  # 修正STR Start数值
            end = match.end(1)
            repeats = len(full_seq) // len(motif)
            if len(full_seq) >= min_bstr_length and min_repeats <= repeats <= max_repeats:
                bstrs.append({
                    'Sequence': full_seq,
                    'STR Start': start,
                    'STR End': end
                })
    return bstrs

# 遍历文件夹并处理所有FASTA文件
files = [f for f in os.listdir(folder_path) if f.endswith('.fas') or f.endswith('.fasta')]

for file in tqdm(files, desc="Processing files"):
    file_path = os.path.join(folder_path, file)
    all_bstr_seqs = []
    non_bstr_seqs = []

    for record in SeqIO.parse(file_path, 'fasta'):
        sequence = str(record.seq).replace('-', '')  # 删除所有的gaps
        bstrs = find_bstrs(sequence)

        # 拼接所有bSTR序列
        bstr_seqs = [bstr['Sequence'] for bstr in bstrs]
        all_bstr_seqs.append((record.id, ''.join(bstr_seqs)))

        # 扣除bSTR后剩余的序列
        sequence_list = list(sequence)  # 转换为可变列表
        removed_positions = set()  # 用于跟踪已移除的位置
        for bstr in bstrs:
            for i in range(bstr['STR Start'] - 1, bstr['STR End']):  # 调整索引到0基准
                if i not in removed_positions:
                    sequence_list[i] = ''  # 移除位置上的字符
                    removed_positions.add(i)

        non_bstr_seq = ''.join(sequence_list)
        non_bstr_seqs.append((record.id, non_bstr_seq))

    # 导出bSTR序列
    bstr_output_file = os.path.join(folder_path, f'treeSTR_data-{os.path.splitext(file)[0]}.fasta')
    with open(bstr_output_file, 'w') as output_handle:
        for seq_id, seq in all_bstr_seqs:
            record = SeqRecord(Seq(seq), id=seq_id, description="")
            SeqIO.write(record, output_handle, "fasta")

    # 导出扣除bSTR后的序列
    non_bstr_output_file = os.path.join(folder_path, f'notreeSTR_data-{os.path.splitext(file)[0]}.fasta')
    with open(non_bstr_output_file, 'w') as output_handle:
        for seq_id, seq in non_bstr_seqs:
            record = SeqRecord(Seq(seq), id=seq_id, description="")
            SeqIO.write(record, output_handle, "fasta")

print("Results saved to respective FASTA files")
