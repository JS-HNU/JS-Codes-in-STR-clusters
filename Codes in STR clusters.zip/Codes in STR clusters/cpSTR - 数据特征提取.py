import os
import re
import pandas as pd
from Bio import SeqIO
from tkinter import Tk, simpledialog
from tkinter.filedialog import askdirectory
from tqdm import tqdm
import numpy as np

# 设置Tkinter不显示根窗口
Tk().withdraw()

# 弹出文件夹检索框
folder_path = askdirectory(title='Select Folder with FASTA files')

# 用户输入设置
min_bstr_length = int(simpledialog.askstring("Input", "Set minimum bSTR total length (bp):"))
min_motif_length = int(simpledialog.askstring("Input", "Set minimum motif length:"))
max_motif_length = int(simpledialog.askstring("Input", "Set maximum motif length:"))
min_repeats = int(simpledialog.askstring("Input", "Set minimum repeats:"))
max_repeats = int(simpledialog.askstring("Input", "Set maximum repeats:"))
max_gap_length = int(simpledialog.askstring("Input", "Set maximum gap length for imperfect STR (bp):"))
min_cpstr_length = int(simpledialog.askstring("Input", "Set minimum cpSTR total length (bp):"))


# 定义bSTR查找函数
def find_bstrs(sequence):
    bstrs = []
    for motif_length in range(min_motif_length, max_motif_length + 1):
        pattern = re.compile(r'((\w{%d})\2{%d,})' % (motif_length, min_repeats - 1))
        for match in pattern.finditer(sequence):
            motif = match.group(2)
            full_seq = match.group(1)
            start = match.start(1)
            end = match.end(1)
            repeats = len(full_seq) // len(motif)
            if len(full_seq) >= min_bstr_length and min_repeats <= repeats <= max_repeats:
                bstrs.append({
                    'Sequence': full_seq,
                    'STR Start': start,
                    'STR End': end,
                    'Motif Length': len(motif),
                    'Repeats': repeats,
                    'Total Length': len(full_seq),
                    'GC Content (%)': (full_seq.count('G') + full_seq.count('C')) / len(full_seq) * 100,
                    'AT Content (%)': (full_seq.count('A') + full_seq.count('T')) / len(full_seq) * 100
                })
    return bstrs


# 定义cpSTR查找函数
def find_cpstrs(bstrs, sequence):
    cpstrs = []
    seen = set()  # 用于跟踪已经处理过的cpSTR，避免重复
    bstrs = sorted(bstrs, key=lambda x: x['STR Start'])  # 按照STR Start排序
    for i in range(len(bstrs) - 1):
        for j in range(i + 1, len(bstrs)):
            bstr1 = bstrs[i]
            bstr2 = bstrs[j]
            gap_length = bstr2['STR Start'] - bstr1['STR End']
            if 0 < gap_length <= max_gap_length:
                cpstr_seq = sequence[bstr1['STR Start']:bstr2['STR End']]
                cpstr_length = len(cpstr_seq)
                if cpstr_length >= min_cpstr_length:
                    cpstr_id = (bstr1['STR Start'], bstr2['STR End'])
                    if cpstr_id not in seen:
                        seen.add(cpstr_id)
                        cpstrs.append({
                            'Type': 'imperfect STR',
                            'Sequence': cpstr_seq,
                            'STR Start': bstr1['STR Start'],
                            'STR End': bstr2['STR End'],
                            'Total Length': cpstr_length,
                            'Gap Length': gap_length,
                            'GC Content (%)': (cpstr_seq.count('G') + cpstr_seq.count('C')) / len(cpstr_seq) * 100,
                            'AT Content (%)': (cpstr_seq.count('A') + cpstr_seq.count('T')) / len(cpstr_seq) * 100,
                            'First bSTR Sequence': bstr1['Sequence'],
                            'First bSTR Motif Length': bstr1['Motif Length'],
                            'First bSTR Repeats': bstr1['Repeats'],
                            'First bSTR Length': bstr1['Total Length'],
                            'First bSTR GC Content (%)': bstr1['GC Content (%)'],
                            'First bSTR AT Content (%)': bstr1['AT Content (%)'],
                            'Second bSTR Sequence': bstr2['Sequence'],
                            'Second bSTR Motif Length': bstr2['Motif Length'],
                            'Second bSTR Repeats': bstr2['Repeats'],
                            'Second bSTR Length': bstr2['Total Length'],
                            'Second bSTR GC Content (%)': bstr2['GC Content (%)'],
                            'Second bSTR AT Content (%)': bstr2['AT Content (%)']
                        })
            elif gap_length == 0:
                cpstr_seq = sequence[bstr1['STR Start']:bstr2['STR End']]
                cpstr_length = len(cpstr_seq)
                if cpstr_length >= min_cpstr_length:
                    cpstr_id = (bstr1['STR Start'], bstr2['STR End'])
                    if cpstr_id not in seen:
                        seen.add(cpstr_id)
                        cpstrs.append({
                            'Type': 'perfect STR',
                            'Sequence': cpstr_seq,
                            'STR Start': bstr1['STR Start'],
                            'STR End': bstr2['STR End'],
                            'Total Length': cpstr_length,
                            'Gap Length': gap_length,
                            'GC Content (%)': (cpstr_seq.count('G') + cpstr_seq.count('C')) / len(cpstr_seq) * 100,
                            'AT Content (%)': (cpstr_seq.count('A') + cpstr_seq.count('T')) / len(cpstr_seq) * 100,
                            'First bSTR Sequence': bstr1['Sequence'],
                            'First bSTR Motif Length': bstr1['Motif Length'],
                            'First bSTR Repeats': bstr1['Repeats'],
                            'First bSTR Length': bstr1['Total Length'],
                            'First bSTR GC Content (%)': bstr1['GC Content (%)'],
                            'First bSTR AT Content (%)': bstr1['AT Content (%)'],
                            'Second bSTR Sequence': bstr2['Sequence'],
                            'Second bSTR Motif Length': bstr2['Motif Length'],
                            'Second bSTR Repeats': bstr2['Repeats'],
                            'Second bSTR Length': bstr2['Total Length'],
                            'Second bSTR GC Content (%)': bstr2['GC Content (%)'],
                            'Second bSTR AT Content (%)': bstr2['AT Content (%)']
                        })
    return cpstrs


# 定义计算数值型基本特征的函数
def calculate_features(cpstrs, sequence_length):
    features = {
        'cpSTR Count': 0,
        'Perfect STR Count': 0,
        'Imperfect STR Count': 0,
        'Total Length': 0,
        'GC Content (%)': 0,
        'AT Content (%)': 0,
        'cpSTR Length relative density (%)': 0,
        'cpSTR Number relative density (units/bp)': 0,
        'First Motif Length': 0,
        'First Repeats': 0,
        'First Total Length': 0,
        'First GC Content (%)': 0,
        'First AT Content (%)': 0,
        'Second Motif Length': 0,
        'Second Repeats': 0,
        'Second Total Length': 0,
        'Second GC Content (%)': 0,
        'Second AT Content (%)': 0
    }
    if cpstrs:
        total_length = np.mean([cpstr['Total Length'] for cpstr in cpstrs])
        perfect_count = sum(1 for cpstr in cpstrs if cpstr['Type'] == 'perfect STR')
        imperfect_count = sum(1 for cpstr in cpstrs if cpstr['Type'] == 'imperfect STR')
        cpstr_total = perfect_count + imperfect_count
        gc_content = sum(cpstr['GC Content (%)'] for cpstr in cpstrs) / len(cpstrs)
        at_content = sum(cpstr['AT Content (%)'] for cpstr in cpstrs) / len(cpstrs)
        relative_density_length = sum(cpstr['Total Length'] for cpstr in cpstrs) / sequence_length * 100
        relative_density_count = (len(cpstrs)* 100) / sequence_length
        first_motif_length = np.mean([cpstr['First bSTR Motif Length'] for cpstr in cpstrs])
        first_repeats = np.mean([cpstr['First bSTR Repeats'] for cpstr in cpstrs])
        first_total_length = np.mean([cpstr['First bSTR Length'] for cpstr in cpstrs])
        first_gc_content = np.mean([cpstr['First bSTR GC Content (%)'] for cpstr in cpstrs])
        first_at_content = np.mean([cpstr['First bSTR AT Content (%)'] for cpstr in cpstrs])
        second_motif_length = np.mean([cpstr['Second bSTR Motif Length'] for cpstr in cpstrs])
        second_repeats = np.mean([cpstr['Second bSTR Repeats'] for cpstr in cpstrs])
        second_total_length = np.mean([cpstr['Second bSTR Length'] for cpstr in cpstrs])
        second_gc_content = np.mean([cpstr['Second bSTR GC Content (%)'] for cpstr in cpstrs])
        second_at_content = np.mean([cpstr['Second bSTR AT Content (%)'] for cpstr in cpstrs])

        features.update({
            'cpSTR Count': cpstr_total,
            'Perfect STR Count': perfect_count,
            'Imperfect STR Count': imperfect_count,
            'Total Length': total_length,
            'GC Content (%)': gc_content,
            'AT Content (%)': at_content,
            'cpSTR Length relative density (%)': relative_density_length,
            'cpSTR Number relative density (units/bp)': relative_density_count,
            'First Motif Length': first_motif_length,
            'First Repeats': first_repeats,
            'First Total Length': first_total_length,
            'First GC Content (%)': first_gc_content,
            'First AT Content (%)': first_at_content,
            'Second Motif Length': second_motif_length,
            'Second Repeats': second_repeats,
            'Second Total Length': second_total_length,
            'Second GC Content (%)': second_gc_content,
            'Second AT Content (%)': second_at_content
        })
    return features


# 遍历文件夹并处理所有FASTA文件
files = [f for f in os.listdir(folder_path) if f.endswith('.fas') or f.endswith('.fasta')]

for file in tqdm(files, desc="Processing files"):
    file_path = os.path.join(folder_path, file)
    all_cpstr_features = []
    for record in SeqIO.parse(file_path, 'fasta'):
        sequence = str(record.seq).replace('-', '')  # 删除所有的gaps
        bstrs = find_bstrs(sequence)
        cpstrs = find_cpstrs(bstrs, sequence)
        features = calculate_features(cpstrs, len(sequence))
        features['Sequence ID'] = record.description
        all_cpstr_features.append(features)

    df = pd.DataFrame(all_cpstr_features)

    # 重新排列列顺序
    column_order = ['Sequence ID', 'cpSTR Count', 'Perfect STR Count', 'Imperfect STR Count', 'Total Length',
                    'GC Content (%)', 'AT Content (%)', 'cpSTR Length relative density (%)', 'cpSTR Number relative density (units/bp)',
                    'First Motif Length', 'First Repeats', 'First Total Length', 'First GC Content (%)',
                    'First AT Content (%)', 'Second Motif Length', 'Second Repeats', 'Second Total Length',
                    'Second GC Content (%)', 'Second AT Content (%)']
    df = df[column_order]

    # 计算每列的平均值和标准差，并添加到最后两行
    mean_row = df.mean(axis=0, numeric_only=True).to_dict()
    mean_row['Sequence ID'] = 'Avg'
    std_row = df.std(axis=0, numeric_only=True).to_dict()
    std_row['Sequence ID'] = 'SD'
    df = pd.concat([df, pd.DataFrame([mean_row, std_row])], ignore_index=True)

    # 保存结果到单独的Excel文件
    excel_filename = f'cpSTR_data_features-{os.path.splitext(file)[0]}.xlsx'
    df.to_excel(excel_filename, index=False)

print("Results saved to respective Excel files")
