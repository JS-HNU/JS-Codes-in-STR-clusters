import os
import re
import pandas as pd
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Data import CodonTable
from tkinter import Tk, simpledialog
from tkinter.filedialog import askdirectory
from tqdm import tqdm
import numpy as np

# 设置Tkinter不显示根窗口
Tk().withdraw()

# 弹出文件夹检索框
folder_path = askdirectory(title='Select Folder with FASTA files')

# 用户输入设置
min_bstr_length = int(simpledialog.askstring("Input", "Set minimum bSTR total length (bp):"))
min_motif_length = int(simpledialog.askstring("Input", "Set minimum motif length:"))
max_motif_length = int(simpledialog.askstring("Input", "Set maximum motif length:"))
min_repeats = int(simpledialog.askstring("Input", "Set minimum repeats:"))
max_repeats = int(simpledialog.askstring("Input", "Set maximum repeats:"))

# 自定义计算GC含量的函数
def calculate_gc_content(sequence):
    gc_count = sequence.count('G') + sequence.count('C')
    return (gc_count / len(sequence)) * 100 if len(sequence) > 0 else 0

# 自定义计算RSCU值的函数，包含终止密码子
def calculate_rscu(sequence):
    codon_table = CodonTable.unambiguous_dna_by_id[1]
    codon_counts = {codon: 0 for codon in codon_table.forward_table}
    codon_counts.update({'TAA': 0, 'TAG': 0, 'TGA': 0})  # 包含终止密码子
    total_codons = 0

    for i in range(0, len(sequence) - 2, 3):
        codon = sequence[i:i + 3]
        if codon in codon_counts:
            codon_counts[codon] += 1
            total_codons += 1

    aa_frequencies = {aa: 0 for aa in codon_table.forward_table.values()}
    aa_frequencies.update({'*': 0})  # 包含终止密码子的频率
    for codon, count in codon_counts.items():
        aa = codon_table.forward_table.get(codon, '*')
        aa_frequencies[aa] += count

    for aa in aa_frequencies:
        aa_frequencies[aa] = (aa_frequencies[aa] / total_codons) * 100 if total_codons > 0 else 0

    return aa_frequencies

# 定义bSTR查找函数
def find_bstrs(sequence):
    bstrs = []
    for motif_length in range(min_motif_length, max_motif_length + 1):
        pattern = re.compile(r'((\w{%d})\2{%d,})' % (motif_length, min_repeats - 1))
        for match in pattern.finditer(sequence):
            motif = match.group(2)
            full_seq = match.group(1)
            start = match.start(1) + 1  # 修正STR Start数值
            end = match.end(1)
            repeats = len(full_seq) // len(motif)
            gc_content = calculate_gc_content(full_seq)
            at_content = 100 - gc_content
            if len(full_seq) >= min_bstr_length and min_repeats <= repeats <= max_repeats:
                bstrs.append({
                    'Sequence': full_seq,
                    'STR Start': start,
                    'STR End': end,
                    'Motif Length': len(motif),
                    'Repeats': repeats,
                    'Total Length': len(full_seq),
                    'GC Content (%)': gc_content,
                    'AT Content (%)': at_content
                })
    return bstrs

# 筛选coSTR函数
def find_costrs(bstrs):
    costrs = []
    for bstr in bstrs:
        if bstr['Total Length'] % 3 == 0:
            protein_seq = str(Seq(bstr['Sequence']).translate(to_stop=True))
            bstr['Protein Sequence'] = re.sub(r'(TAG|TAA|TGA)', '*', protein_seq)  # 明确替换终止密码子为“*”
            costrs.append(bstr)
    return costrs

# 定义函数以统计数值型基本特征平均值
def calculate_features(costrs, bstrs_count, sequence_length, min_motif_length, max_motif_length, min_repeats, max_repeats):
    if len(costrs) == 0:
        return {}
    num_costrs = len(costrs)
    motif_lengths = [costr['Motif Length'] for costr in costrs]
    repeats = [costr['Repeats'] for costr in costrs]
    total_lengths = [costr['Total Length'] for costr in costrs]
    gc_contents = [costr['GC Content (%)'] for costr in costrs]
    at_contents = [costr['AT Content (%)'] for costr in costrs]
    dna_sequences = ''.join(costr['Sequence'] for costr in costrs)

    rscu_values = calculate_rscu(dna_sequences)

    features = {
        'coSTR Count': num_costrs,
        'Motif Length Mean': np.mean(motif_lengths),
        'Repeats Mean': np.mean(repeats),
        'Total Length Mean': np.mean(total_lengths),
        'GC Content Mean (%)': np.mean(gc_contents),
        'AT Content Mean (%)': np.mean(at_contents),
        'coSTR Length relative density (%)': (sum(total_lengths) * 100) / sequence_length if sequence_length > 0 else 0,
        'coSTR Number relative density (%)': (num_costrs * 100) / sequence_length if sequence_length > 0 else 0,
        'coSTR Proportion (%)': (num_costrs / bstrs_count) * 100 if bstrs_count > 0 else 0
    }

    for i in range(min_motif_length, max_motif_length + 1):
        features[f'Motif Length Proportion_{i}'] = (motif_lengths.count(i) / num_costrs) * 100

    for i in range(min_repeats, max_repeats + 1):
        features[f'Repeats Proportion_{i}'] = (repeats.count(i) / num_costrs) * 100

    features['RSCU Values'] = rscu_values

    return features

# 遍历文件夹并处理所有FASTA文件
files = [f for f in os.listdir(folder_path) if f.endswith('.fas') or f.endswith('.fasta')]

for file in tqdm(files, desc="Processing files"):
    file_path = os.path.join(folder_path, file)
    results = []
    rscu_values_list = []

    for record in SeqIO.parse(file_path, 'fasta'):
        sequence = str(record.seq).replace('-', '')  # 删除所有的gaps
        bstrs = find_bstrs(sequence)
        costrs = find_costrs(bstrs)
        sequence_length = len(sequence)
        features = calculate_features(costrs, len(bstrs), sequence_length, min_motif_length, max_motif_length, min_repeats, max_repeats)
        features['Sequence ID'] = record.description  # 使用record.description获取完整序列描述

        # 分离RSCU值
        rscu_values = features.pop('RSCU Values')
        rscu_values['Sequence ID'] = record.description

        results.append(features)
        rscu_values_list.append(rscu_values)

    # 转换结果为DataFrame
    df = pd.DataFrame(results)
    rscu_df = pd.DataFrame(rscu_values_list).fillna(0)

    # 计算每列的平均值和标准差
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    df.loc['Avg'] = df[numeric_cols].mean()
    df.loc['SD'] = df[numeric_cols].std()
    df.loc['Avg', 'Sequence ID'] = 'Avg'
    df.loc['SD', 'Sequence ID'] = 'SD'

    # 设置列的顺序
    columns_order = ['Sequence ID', 'coSTR Count', 'Motif Length Mean', 'Repeats Mean', 'Total Length Mean'] + \
                    [col for col in df.columns if col.startswith('Motif Length Proportion')] + \
                    [col for col in df.columns if col.startswith('Repeats Proportion')] + \
                    ['GC Content Mean (%)', 'AT Content Mean (%)', 'coSTR Length relative density (%)', 'coSTR Number relative density (%)', 'coSTR Proportion (%)']

    df = df[columns_order]

    # 计算RSCU值的平均值和标准差
    rscu_numeric_cols = rscu_df.select_dtypes(include=[np.number]).columns

    rscu_df.loc['Avg'] = rscu_df[rscu_numeric_cols].mean()
    rscu_df.loc['SD'] = rscu_df[rscu_numeric_cols].std()
    rscu_df.loc['Avg', 'Sequence ID'] = 'Avg'
    rscu_df.loc['SD', 'Sequence ID'] = 'SD'

    # 确保 "Sequence ID" 是第一列
    rscu_df = rscu_df[['Sequence ID'] + [col for col in rscu_df.columns if col != 'Sequence ID']]

    # 导出结果到Excel文件
    output_file = os.path.join(folder_path, f"coSTR_data_features-{os.path.splitext(file)[0]}.xlsx")
    with pd.ExcelWriter(output_file) as writer:
        df.to_excel(writer, sheet_name='Features', index=False)
        rscu_df.to_excel(writer, sheet_name='RSCU Values', index=False)

print("Results saved to individual Excel files.")
