import os
import re
import pandas as pd
from Bio import SeqIO
from tkinter import Tk, simpledialog
from tkinter.filedialog import askdirectory
from tqdm import tqdm
import numpy as np
import xlsxwriter

# 设置Tkinter不显示根窗口
Tk().withdraw()

# 弹出文件夹检索框
folder_path = askdirectory(title='Select Folder with FASTA files')

# 用户输入设置
min_bstr_length = int(simpledialog.askstring("Input", "Set minimum bSTR total length (bp):"))
min_motif_length = int(simpledialog.askstring("Input", "Set minimum motif length:"))
max_motif_length = int(simpledialog.askstring("Input", "Set maximum motif length:"))
min_repeats = int(simpledialog.askstring("Input", "Set minimum repeats:"))
max_repeats = int(simpledialog.askstring("Input", "Set maximum repeats:"))
N_length = int(simpledialog.askstring("Input", "Set the length of N (bp):"))
M_length = int(simpledialog.askstring("Input", "Set the length of M (bp):"))
min_ssmSTR_length = int(simpledialog.askstring("Input", "Set minimum ssmSTR total length (bp):"))

# 定义bSTR查找函数
def find_bstrs(sequence):
    bstrs = []
    for motif_length in range(min_motif_length, max_motif_length + 1):
        pattern = re.compile(r'((\w{%d})\2{%d,})' % (motif_length, min_repeats - 1))
        for match in pattern.finditer(sequence):
            motif = match.group(2)
            full_seq = match.group(1)
            start = match.start(1) + 1  # 修正STR Start数值
            end = match.end(1)
            repeats = len(full_seq) // len(motif)
            if len(full_seq) >= min_bstr_length and min_repeats <= repeats <= max_repeats:
                bstrs.append({
                    'Sequence': full_seq,
                    'STR Start': start,
                    'STR End': end,
                    'Motif Length': len(motif),
                    'Repeats': repeats,
                    'Total Length': len(full_seq)
                })
    return bstrs

# 定义查找滑动错配的函数
def find_ssmstrs(sequence, bstrs):
    ssmstrs = []
    for bstr in bstrs:
        start = bstr['STR Start'] - 1
        end = bstr['STR End']
        region_start = max(0, start - N_length)
        region_end = min(len(sequence), end + M_length)
        search_region = sequence[region_start:region_end]

        pattern = re.compile(r'((\w{%d})\2{%d,})' % (bstr['Motif Length'], min_repeats - 1))
        mismatches = []
        for match in pattern.finditer(search_region):
            if match.start() + region_start != start:
                mismatches.append(match.group(1))

        if mismatches:
            ssmstr = bstr.copy()
            ssmstr_length = len(bstr['Sequence'])
            if ssmstr_length >= min_ssmSTR_length:
                gc_content = (bstr['Sequence'].count('G') + bstr['Sequence'].count('C')) / ssmstr_length * 100
                at_content = (bstr['Sequence'].count('A') + bstr['Sequence'].count('T')) / ssmstr_length * 100
                ssmstr['GC Content (%)'] = gc_content
                ssmstr['AT Content (%)'] = at_content
                ssmstr['Mismatches'] = mismatches
                ssmstrs.append(ssmstr)
            else:
                ssmstr['Mismatches'] = mismatches  # 修正漏掉第一个ssmSTR的问题
                ssmstrs.append(ssmstr)

    return ssmstrs

# 计算统计数据
def calculate_statistics(ssmstrs, sequence_length):
    stats = {
        'Sequence ID': None,  # 占位符，将在稍后分配
        'ssmSTR Count': len(ssmstrs),
        'Mismatches Count': sum(len(ssmstr['Mismatches']) for ssmstr in ssmstrs),
        'Average Motif Length': np.mean([ssmstr['Motif Length'] for ssmstr in ssmstrs]) if ssmstrs else 0,
        'Average Repeats': np.mean([ssmstr['Repeats'] for ssmstr in ssmstrs]) if ssmstrs else 0,
        'Average Length': np.mean([ssmstr['Total Length'] for ssmstr in ssmstrs]) if ssmstrs else 0,
    }

    motif_length_proportions = {f'Motif Length Proportion_{i}': 0 for i in range(min_motif_length, max_motif_length + 1)}
    for ssmstr in ssmstrs:
        motif_length_proportions[f'Motif Length Proportion_{ssmstr["Motif Length"]}'] += 1
    for k in motif_length_proportions.keys():
        motif_length_proportions[k] = (motif_length_proportions[k] / stats['ssmSTR Count']) * 100 if stats['ssmSTR Count'] > 0 else 0

    repeats_proportions = {f'Repeats Proportion_{i}': 0 for i in range(min_repeats, max_repeats + 1)}
    for ssmstr in ssmstrs:
        repeats_proportions[f'Repeats Proportion_{ssmstr["Repeats"]}'] += 1
    for k in repeats_proportions.keys():
        repeats_proportions[k] = (repeats_proportions[k] / stats['ssmSTR Count']) * 100 if stats['ssmSTR Count'] > 0 else 0

    stats['GC Content (%)'] = np.mean([ssmstr['GC Content (%)'] for ssmstr in ssmstrs]) if ssmstrs else 0
    stats['AT Content (%)'] = np.mean([ssmstr['AT Content (%)'] for ssmstr in ssmstrs]) if ssmstrs else 0
    stats['ssmSTR Length Density (%)'] = sum(ssmstr['Total Length'] for ssmstr in ssmstrs) * 100 / sequence_length if ssmstrs else 0
    stats['ssmSTR Count Density (%)'] = len(ssmstrs) * 100 / sequence_length if ssmstrs else 0

    stats.update(motif_length_proportions)
    stats.update(repeats_proportions)
    return stats

# 遍历文件夹并处理所有FASTA文件
files = [f for f in os.listdir(folder_path) if f.endswith('.fas') or f.endswith('.fasta')]

for file in tqdm(files, desc="Processing files"):
    file_path = os.path.join(folder_path, file)
    results = []
    for record in SeqIO.parse(file_path, 'fasta'):
        sequence = str(record.seq)  # 保留所有的gaps
        bstrs = find_bstrs(sequence)
        ssmstrs = find_ssmstrs(sequence, bstrs)

        sequence_length = len(sequence)
        stats = calculate_statistics(ssmstrs, sequence_length)
        stats['Sequence ID'] = record.description
        results.append(stats)

    df = pd.DataFrame(results)
    summary = df.describe().loc[['mean', 'std']]
    summary.loc['mean', 'Sequence ID'] = 'Overall Mean'
    summary.loc['std', 'Sequence ID'] = 'Overall Std'
    df = pd.concat([df, summary], ignore_index=True)

    # 将 "Sequence ID" 移动到第一列
    cols = ['Sequence ID'] + [col for col in df.columns if col != 'Sequence ID']
    df = df[cols]

    # 将 'Motif Length Proportion_{i}' 和 'Repeats Proportion_{i}' 的相关结果放到 “Average Length” 结果列之后
    fixed_cols = ['Sequence ID', 'ssmSTR Count', 'Mismatches Count', 'Average Motif Length', 'Average Repeats', 'Average Length']
    motif_cols = sorted([col for col in df.columns if col.startswith('Motif Length Proportion_')])
    repeats_cols = sorted([col for col in df.columns if col.startswith('Repeats Proportion_')])
    other_cols = ['GC Content (%)', 'AT Content (%)', 'ssmSTR Length Density (%)', 'ssmSTR Count Density (%)']

    df = df[fixed_cols + motif_cols + repeats_cols + other_cols]

    excel_filename = f'ssmSTR_data_features-{os.path.splitext(file)[0]}.xlsx'
    with pd.ExcelWriter(excel_filename, engine='xlsxwriter') as writer:
        df.to_excel(writer, index=False, sheet_name='ssmSTR Features')

print("Results saved to respective Excel files")
