import os
import re
import pandas as pd
from Bio import SeqIO
from tkinter import Tk, simpledialog
from tkinter.filedialog import askdirectory
from tqdm import tqdm
import numpy as np

# 设置Tkinter不显示根窗口
Tk().withdraw()

# 弹出文件夹检索框
folder_path = askdirectory(title='Select Folder with FASTA files')

# 用户输入设置
min_bvSTR_length = int(simpledialog.askstring("Input", "Set minimum bvSTR total length (bp):"))
min_motif_length = int(simpledialog.askstring("Input", "Set minimum motif length:"))
max_motif_length = int(simpledialog.askstring("Input", "Set maximum motif length:"))
min_repeats = int(simpledialog.askstring("Input", "Set minimum repeats:"))
max_repeats = int(simpledialog.askstring("Input", "Set maximum repeats:"))

# 定义bvSTR查找函数
def find_bvSTRs(sequence):
    bvSTRs = []
    for motif_length in range(min_motif_length, max_motif_length + 1):
        pattern = re.compile(r'((\w{%d})\2{%d,})' % (motif_length, min_repeats - 1))
        for match in pattern.finditer(sequence):
            motif = match.group(2)
            full_seq = match.group(1)
            repeats = len(full_seq) // len(motif)
            gc_content = (full_seq.count('G') + full_seq.count('C')) / len(full_seq) * 100
            at_content = 100 - gc_content
            if len(full_seq) >= min_bvSTR_length and min_repeats <= repeats <= max_repeats:
                bvSTRs.append({
                    'Sequence': full_seq,
                    'Motif Length': len(motif),
                    'Repeats': repeats,
                    'Total Length': len(full_seq),
                    'GC Content (%)': gc_content,
                    'AT Content (%)': at_content
                })
    return bvSTRs

# 统计数值型基本特征平均值
def calculate_features(bvSTRs, sequence_length):
    features = {
        'bvSTR Count': len(bvSTRs),
        'Motif Length Mean': 0,
        'Repeats Mean': 0,
        'Total Length Mean': 0,
        'GC Content Mean (%)': 0,
        'AT Content Mean (%)': 0,
        'bvSTR Length relative density (%)': 0,
        'bvSTR Number relative density (units/bp)': 0
    }

    if bvSTRs:
        bvSTR_df = pd.DataFrame(bvSTRs)
        features.update({
            'Motif Length Mean': bvSTR_df['Motif Length'].mean(),
            'Repeats Mean': bvSTR_df['Repeats'].mean(),
            'Total Length Mean': bvSTR_df['Total Length'].mean(),
            'GC Content Mean (%)': bvSTR_df['GC Content (%)'].mean(),
            'AT Content Mean (%)': bvSTR_df['AT Content (%)'].mean(),
            'bvSTR Length relative density (%)': (bvSTR_df['Total Length'].sum() * 100) / sequence_length if sequence_length > 0 else 0,
            'bvSTR Number relative density (units/bp)': (len(bvSTRs) * 100) / sequence_length if sequence_length > 0 else 0
        })

        for i in range(min_motif_length, max_motif_length + 1):
            features[f'Motif Length Proportion_{i}'] = (bvSTR_df['Motif Length'] == i).mean() * 100

        for i in range(min_repeats, max_repeats + 1):
            features[f'Repeats Proportion_{i}'] = (bvSTR_df['Repeats'] == i).mean() * 100

    return features

# 遍历文件夹并处理所有FASTA文件
files = [f for f in os.listdir(folder_path) if f.endswith('.fas') or f.endswith('.fasta')]

for file in tqdm(files, desc="Processing files"):
    file_path = os.path.join(folder_path, file)
    results = []
    for record in SeqIO.parse(file_path, 'fasta'):
        sequence = str(record.seq).replace('-', '')  # 删除所有的gaps
        bvSTRs = find_bvSTRs(sequence)
        sequence_length = len(sequence)
        features = calculate_features(bvSTRs, sequence_length)
        features['Sequence ID'] = record.description  # 使用record.description获取完整序列描述
        results.append(features)

    # 转换结果为DataFrame
    df = pd.DataFrame(results)

    # 选择数值型列以计算平均值和标准差
    numeric_cols = df.select_dtypes(include=[np.number]).columns

    # 计算每列的平均值和标准差
    df.loc['Avg'] = df[numeric_cols].mean()
    df.loc['SD'] = df[numeric_cols].std()

    # 设置行标题
    df.loc['Avg', 'Sequence ID'] = 'Avg'
    df.loc['SD', 'Sequence ID'] = 'SD'

    # 移动'GC Content Mean (%)', 'AT Content Mean (%)' 和 'bvSTR Length relative density (%)' 到 'Repeats Proportion' 的后面
    columns_order = ['Sequence ID', 'bvSTR Count', 'Motif Length Mean', 'Repeats Mean', 'Total Length Mean'] + \
                    [col for col in df.columns if col.startswith('Motif Length Proportion')] + \
                    [col for col in df.columns if col.startswith('Repeats Proportion')] + \
                    ['GC Content Mean (%)', 'AT Content Mean (%)', 'bvSTR Length relative density (%)', 'bvSTR Number relative density (units/bp)']

    df = df[columns_order]

    # 导出结果到Excel文件，文件名格式为'bvSTR_data_features-文件名.xlsx'
    output_file = os.path.join(folder_path, f"bvSTR_data_features-{os.path.splitext(file)[0]}.xlsx")
    df.to_excel(output_file, index=False)

print("Results saved to individual Excel files.")
