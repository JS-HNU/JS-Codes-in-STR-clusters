import os
import re
import pandas as pd
from Bio import SeqIO
from tkinter import Tk, simpledialog
from tkinter.filedialog import askdirectory
from tqdm import tqdm
import numpy as np

# 设置Tkinter不显示根窗口
Tk().withdraw()

# 弹出文件夹检索框
folder_path = askdirectory(title='Select Folder with FASTA files')

# 用户输入设置
N = int(simpledialog.askstring("Input", "Set N (bp length to the left of bSTR):"))
M = int(simpledialog.askstring("Input", "Set M (bp length to the right of bSTR):"))
min_bstr_length = int(simpledialog.askstring("Input", "Set minimum bSTR total length (bp):"))
min_motif_length = int(simpledialog.askstring("Input", "Set minimum motif length:"))
max_motif_length = int(simpledialog.askstring("Input", "Set maximum motif length:"))
min_repeats = int(simpledialog.askstring("Input", "Set minimum repeats:"))
max_repeats = int(simpledialog.askstring("Input", "Set maximum repeats:"))
min_ssdstr_length = int(simpledialog.askstring("Input", "Set minimum ssdSTR total length (bp):"))

# 定义 bSTR 查找函数
def find_bstrs(sequence):
    bstrs = []
    for motif_length in range(min_motif_length, max_motif_length + 1):
        pattern = re.compile(r'((\w{%d})\2{%d,})' % (motif_length, min_repeats - 1))
        for match in pattern.finditer(sequence):
            motif = match.group(2)
            full_seq = match.group(1)
            start = match.start(1) + 1  # 修正 STR Start 数值
            end = match.end(1)
            repeats = len(full_seq) // len(motif)
            gc_content = (full_seq.count('G') + full_seq.count('C')) / len(full_seq) * 100
            at_content = (full_seq.count('A') + full_seq.count('T')) / len(full_seq) * 100
            if len(full_seq) >= min_bstr_length and min_repeats <= repeats <= max_repeats:
                bstrs.append({
                    'Sequence': full_seq,
                    'STR Start': start,
                    'STR End': end,
                    'Motif Length': len(motif),
                    'Repeats': repeats,
                    'Total Length': len(full_seq),
                    'GC Content (%)': gc_content,
                    'AT Content (%)': at_content
                })
    return bstrs

# 定义 ssdSTR 查找函数
def find_ssdstrs(sequence, bstrs, N, M):
    ssdstrs = []
    for bstr in bstrs:
        bstr_seq = bstr['Sequence']
        bstr_start = bstr['STR Start'] - 1  # 转换为 0 索引
        bstr_end = bstr['STR End']
        search_start = max(bstr_start - N, 0)
        search_end = min(bstr_end + M, len(sequence))
        search_region = sequence[search_start:search_end]

        rssdstrs = []
        for motif_length in range(min_motif_length, max_motif_length + 1):
            pattern = re.compile(r'((\w{%d})\2{%d,})' % (motif_length, 1))
            for match in pattern.finditer(search_region):
                motif = match.group(2)
                full_seq = match.group(1)
                start = search_start + match.start(1) + 1
                end = search_start + match.end(1)
                repeats = len(full_seq) // len(motif)
                if motif == bstr_seq[:motif_length] and len(full_seq) != len(bstr_seq):
                    rssdstrs.append({
                        'Sequence': full_seq,
                        'STR Start': start,
                        'STR End': end,
                        'Motif Length': len(motif),
                        'Repeats': repeats,
                        'Total Length': len(full_seq)
                    })
        if len(rssdstrs) > 0 and bstr['Total Length'] >= min_ssdstr_length:
            ssdstrs.append({
                'ssdSTR': bstr,
                'rssdSTRs': rssdstrs
            })
    return ssdstrs

# 计算数值型基本特征的平均值
def calculate_features(ssdstrs):
    ssdstr_count = len(ssdstrs)
    rssdstr_count = sum(len(item['rssdSTRs']) for item in ssdstrs)
    motif_lengths = [item['ssdSTR']['Motif Length'] for item in ssdstrs]
    repeats = [item['ssdSTR']['Repeats'] for item in ssdstrs]
    lengths = [item['ssdSTR']['Total Length'] for item in ssdstrs]
    gc_contents = [item['ssdSTR']['GC Content (%)'] for item in ssdstrs]
    at_contents = [item['ssdSTR']['AT Content (%)'] for item in ssdstrs]

    motif_proportion = {f'Motif Length Proportion_{i}': 0 for i in range(min_motif_length, max_motif_length + 1)}
    repeats_proportion = {f'Repeats Proportion_{i}': 0 for i in range(min_repeats, max_repeats + 1)}

    for ml in motif_lengths:
        motif_proportion[f'Motif Length Proportion_{ml}'] += 1
    for rp in repeats:
        repeats_proportion[f'Repeats Proportion_{rp}'] += 1

    for key in motif_proportion:
        motif_proportion[key] = (motif_proportion[key] / ssdstr_count) * 100 if ssdstr_count > 0 else 0
    for key in repeats_proportion:
        repeats_proportion[key] = (repeats_proportion[key] / ssdstr_count) * 100 if ssdstr_count > 0 else 0

    feature_means = {
        'Sequence ID': '',
        'ssdSTR Count': ssdstr_count,
        'rssdSTR Count': rssdstr_count,
        'Motif Length Mean': sum(motif_lengths) / ssdstr_count if ssdstr_count > 0 else 0,
        'Repeats Mean': sum(repeats) / ssdstr_count if ssdstr_count > 0 else 0,
        'Total Length Mean': sum(lengths) / ssdstr_count if ssdstr_count > 0 else 0,
        'GC Content Mean (%)': sum(gc_contents) / ssdstr_count if ssdstr_count > 0 else 0,
        'AT Content Mean (%)': sum(at_contents) / ssdstr_count if ssdstr_count > 0 else 0
    }
    feature_means.update(motif_proportion)
    feature_means.update(repeats_proportion)
    return feature_means

# 遍历并处理所有 FASTA 文件
files = [f for f in os.listdir(folder_path) if f.endswith('.fas') or f.endswith('.fasta')]

for file in tqdm(files, desc="Processing files"):
    file_path = os.path.join(folder_path, file)
    all_results = []
    for record in SeqIO.parse(file_path, 'fasta'):
        sequence = str(record.seq)  # 保留 gaps
        bstrs = find_bstrs(sequence)
        ssdstrs = find_ssdstrs(sequence, bstrs, N, M)
        features = calculate_features(ssdstrs)
        features['Sequence ID'] = record.description
        all_results.append(features)

    # 保存结果到 Excel
    df = pd.DataFrame(all_results)

    # 调整列顺序
    columns_order = [
        'Sequence ID', 'ssdSTR Count', 'rssdSTR Count',
        'Motif Length Mean', 'Repeats Mean', 'Total Length Mean'
    ] + [col for col in df.columns if col.startswith('Motif Length Proportion')] + \
        [col for col in df.columns if col.startswith('Repeats Proportion')] + \
        ['GC Content Mean (%)', 'AT Content Mean (%)']

    df = df[columns_order]

    # 计算平均值和标准差行
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    df.loc['Avg'] = df[numeric_cols].mean()
    df.loc['SD'] = df[numeric_cols].std()
    df.loc['Avg', 'Sequence ID'] = 'Avg'
    df.loc['SD', 'Sequence ID'] = 'SD'

    excel_filename = f'ssdSTR&rssdSTR_data_features-{os.path.splitext(file)[0]}.xlsx'
    df.to_excel(excel_filename, index=False)

print("Results saved to respective Excel files")
