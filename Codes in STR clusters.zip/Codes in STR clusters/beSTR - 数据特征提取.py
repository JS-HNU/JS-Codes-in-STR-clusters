import os
import re
import pandas as pd
from Bio.Seq import Seq
from tkinter import Tk, simpledialog, filedialog
from tqdm import tqdm

# 设置Tkinter不显示根窗口
Tk().withdraw()

# 弹出文件夹检索框
folder_path = filedialog.askdirectory(title='Select Folder with XLSX files')

# 用户输入设置
min_total_length = int(simpledialog.askstring("Input", "Set minimum total length for beSTR (amino acids):"))
min_motif_length = int(simpledialog.askstring("Input", "Set minimum motif length (amino acids):"))
max_motif_length = int(simpledialog.askstring("Input", "Set maximum motif length (amino acids):"))
min_repeats = int(simpledialog.askstring("Input", "Set minimum repeats:"))
max_repeats = int(simpledialog.askstring("Input", "Set maximum repeats:"))


# 定义beSTR查找函数
def find_bestrs(sequence):
    bestrs = []
    for motif_length in range(min_motif_length, max_motif_length + 1):
        pattern = re.compile(r'((\w{%d})\2{%d,})' % (motif_length, min_repeats - 1))
        for match in pattern.finditer(sequence):
            full_seq = match.group(1)
            start = match.start(1) + 1
            end = match.end(1)
            repeats = len(full_seq) // motif_length
            if len(full_seq) >= min_total_length and min_repeats <= repeats <= max_repeats:
                bestrs.append({
                    'Full Sequence': full_seq,
                    'Motif Length (aa)': motif_length,
                    'Repeats': repeats,
                    'Total Length (aa)': len(full_seq),
                    'Start': start,
                    'End': end
                })
    return bestrs


# 统计数值型基本特征
def calculate_features(bestrs, sequence_length):
    features = {
        'beSTR Count': len(bestrs),
        'Average Motif Length': sum(b['Motif Length (aa)'] for b in bestrs) / len(bestrs) if bestrs else 0,
        'Average Repeats': sum(b['Repeats'] for b in bestrs) / len(bestrs) if bestrs else 0,
        'Average beSTR Length': sum(b['Total Length (aa)'] for b in bestrs) / len(bestrs) if bestrs else 0,
        'beSTR Length Relative Density (%)': sum(
            b['Total Length (aa)'] for b in bestrs) / sequence_length * 100 if bestrs else 0,
        'beSTR Number Relative Density (units/bp)': (len(bestrs) * 100) / sequence_length if bestrs else 0,
    }
    motif_lengths = [b['Motif Length (aa)'] for b in bestrs]
    repeats = [b['Repeats'] for b in bestrs]
    for ml in range(min_motif_length, max_motif_length + 1):
        features[f'Motif Length Proportion_{ml}'] = motif_lengths.count(ml) / len(bestrs) * 100 if bestrs else 0
    for rp in range(min_repeats, max_repeats + 1):
        features[f'Repeats Proportion_{rp}'] = repeats.count(rp) / len(bestrs) * 100 if bestrs else 0
    return features


# 遍历文件夹并处理所有XLSX文件
files = [f for f in os.listdir(folder_path) if f.endswith('.xlsx')]

for file in tqdm(files, desc="Processing files"):
    file_path = os.path.join(folder_path, file)
    df = pd.read_excel(file_path)
    all_results = []

    if 'Name' in df.columns:
        for index, row in df.iterrows():
            sequence = row['Name']
            bestrs = find_bestrs(sequence)
            if bestrs:  # 仅当存在beSTR时才处理
                features = calculate_features(bestrs, len(sequence))
                for bestr in bestrs:
                    all_results.append({
                        'File': file,
                        'Row': index + 1,
                        'Original Sequence': sequence,
                        **features,
                        'Sequence Length (aa)': len(sequence),
                        'beSTR Length Relative Density (%)': len(bestr['Full Sequence']) / len(sequence) * 100,
                        'beSTR Number Relative Density (%)': (1 / len(sequence)) * 100
                    })

        df_results = pd.DataFrame(all_results)
        if not df_results.empty:
            # 添加平均值和标准差行
            df_mean = pd.DataFrame(df_results.mean(numeric_only=True)).T
            df_std = pd.DataFrame(df_results.std(numeric_only=True)).T
            df_mean['File'] = 'Avg'
            df_std['File'] = 'SD'
            df_results = pd.concat([df_results, df_mean, df_std], ignore_index=True)

            # 调整列的顺序
            cols = list(df_results.columns)
            motif_proportions = [f'Motif Length Proportion_{i}' for i in range(min_motif_length, max_motif_length + 1)]
            repeat_proportions = [f'Repeats Proportion_{i}' for i in range(min_repeats, max_repeats + 1)]
            base_columns = ['File', 'Row', 'Original Sequence', 'beSTR Count', 'Average Motif Length',
                            'Average Repeats', 'Average beSTR Length']
            additional_columns = ['beSTR Length Relative Density (%)', 'beSTR Number Relative Density (%)']
            col_order = base_columns + motif_proportions + repeat_proportions + additional_columns

            # 确保所有列都在新顺序中
            col_order = [col for col in col_order if col in cols]
            df_results = df_results[col_order]

        # 导出结果到Excel
        output_file = f'beSTR_data_features-{os.path.splitext(file)[0]}.xlsx'
        with pd.ExcelWriter(output_file) as writer:
            df_results.to_excel(writer, sheet_name='beSTR Results', index=False)

print("Results saved to respective Excel files")
