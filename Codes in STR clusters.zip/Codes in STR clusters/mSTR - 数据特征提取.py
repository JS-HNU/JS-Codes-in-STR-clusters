import os
import re
import pandas as pd
from Bio import SeqIO
from tkinter import Tk, simpledialog
from tkinter.filedialog import askdirectory
from tqdm import tqdm
import numpy as np

# 设置Tkinter不显示根窗口
Tk().withdraw()

# 弹出文件夹检索框
folder_path = askdirectory(title='Select Folder with FASTA files')

# 用户输入设置
min_bstr_length = int(simpledialog.askstring("Input", "Set minimum bSTR total length (bp):"))
min_motif_length = int(simpledialog.askstring("Input", "Set minimum motif length:"))
max_motif_length = int(simpledialog.askstring("Input", "Set maximum motif length:"))
min_repeats = int(simpledialog.askstring("Input", "Set minimum repeats:"))
max_repeats = int(simpledialog.askstring("Input", "Set maximum repeats:"))
min_mstr_length = int(simpledialog.askstring("Input", "Set minimum mSTR total length (bp):"))

# 定义bSTR查找函数
def find_bstrs(sequence):
    bstrs = []
    for motif_length in range(min_motif_length, max_motif_length + 1):
        pattern = re.compile(r'((\w{%d})\2{%d,})' % (motif_length, min_repeats - 1))
        for match in pattern.finditer(sequence):
            full_seq = match.group(1)
            if len(full_seq) >= min_bstr_length:
                bstrs.append({
                    'Sequence': full_seq,
                    'Motif Length': motif_length,
                    'Repeats': len(full_seq) // motif_length,
                    'GC Content (%)': (full_seq.count('G') + full_seq.count('C')) / len(full_seq) * 100,
                    'AT Content (%)': (full_seq.count('A') + full_seq.count('T')) / len(full_seq) * 100,
                    'Total Length': len(full_seq)
                })
    return bstrs

# 定义mSTR查找函数
def find_mstrs(bstrs):
    return [bstr for bstr in bstrs if 'C' in bstr['Sequence'] and bstr['Total Length'] >= min_mstr_length]

# 计算数值型基本特征
def calculate_features(mstrs, sequence_length, total_bstr_count):
    if not mstrs:
        return {
            'mSTR Count': 0,
            'Motif Length Mean': 0,
            'Repeats Mean': 0,
            'Total Length Mean': 0,
            'GC Content Mean (%)': 0,
            'AT Content Mean (%)': 0,
            'mSTR Length relative density (%)': 0,
            'mSTR Number relative density (units/bp)': 0,
            'mSTR in bSTR (%)': 0,
            **{f'Motif Length Proportion_{i}': 0 for i in range(min_motif_length, max_motif_length + 1)},
            **{f'Repeats Proportion_{i}': 0 for i in range(min_repeats, max_repeats + 1)},
        }

    mstr_df = pd.DataFrame(mstrs)
    return {
        'mSTR Count': len(mstrs),
        'Motif Length Mean': mstr_df['Motif Length'].mean(),
        'Repeats Mean': mstr_df['Repeats'].mean(),
        'Total Length Mean': mstr_df['Total Length'].mean(),
        'GC Content Mean (%)': mstr_df['GC Content (%)'].mean(),
        'AT Content Mean (%)': mstr_df['AT Content (%)'].mean(),
        'mSTR Length relative density (%)': (mstr_df['Total Length'].sum() * 100) / sequence_length if sequence_length > 0 else 0,
        'mSTR Number relative density (units/bp)': (len(mstrs) * 100) / sequence_length if sequence_length > 0 else 0,
        'mSTR in bSTR (%)': (len(mstrs) * 100) / total_bstr_count if total_bstr_count else 0,
        **{f'Motif Length Proportion_{i}': (mstr_df['Motif Length'] == i).mean() * 100 for i in range(min_motif_length, max_motif_length + 1)},
        **{f'Repeats Proportion_{i}': (mstr_df['Repeats'] == i).mean() * 100 for i in range(min_repeats, max_repeats + 1)},
    }

# 遍历文件夹并处理所有FASTA文件
files = [f for f in os.listdir(folder_path) if f.endswith('.fas') or f.endswith('.fasta')]

for file in tqdm(files, desc="Processing files"):
    file_path = os.path.join(folder_path, file)
    results = []
    for record in SeqIO.parse(file_path, 'fasta'):
        sequence = str(record.seq).replace('-', '')  # 删除所有的gaps
        bstrs = find_bstrs(sequence)
        mstrs = find_mstrs(bstrs)
        sequence_length = len(sequence)
        features = calculate_features(mstrs, sequence_length, len(bstrs))
        features['Sequence ID'] = record.description  # 使用record.description获取完整序列描述
        results.append(features)

    # 转换结果为DataFrame
    df = pd.DataFrame(results)

    # 选择数值型列以计算平均值和标准差
    numeric_cols = df.select_dtypes(include=[np.number]).columns

    # 计算每列的平均值和标准差
    df.loc['Avg'] = df[numeric_cols].mean()
    df.loc['SD'] = df[numeric_cols].std()

    # 设置行标题
    df.loc['Avg', 'Sequence ID'] = 'Avg'
    df.loc['SD', 'Sequence ID'] = 'SD'

    # 移动'GC Content Mean (%)', 'AT Content Mean (%)' 和 'mSTR Length relative density (%)' 到 'Repeats Proportion' 的后面
    columns_order = ['Sequence ID', 'mSTR Count', 'Motif Length Mean', 'Repeats Mean', 'Total Length Mean'] + \
                    [col for col in df.columns if col.startswith('Motif Length Proportion')] + \
                    [col for col in df.columns if col.startswith('Repeats Proportion')] + \
                    ['GC Content Mean (%)', 'AT Content Mean (%)', 'mSTR Length relative density (%)', 'mSTR Number relative density (units/bp)', 'mSTR in bSTR (%)']

    df = df[columns_order]

    # 导出结果到Excel文件，文件名格式为'mSTR_data-文件名.xlsx'
    output_file = os.path.join(folder_path, f"mSTR_data_features-{os.path.splitext(file)[0]}.xlsx")
    df.to_excel(output_file, index=False)

print("Results saved to individual Excel files.")
