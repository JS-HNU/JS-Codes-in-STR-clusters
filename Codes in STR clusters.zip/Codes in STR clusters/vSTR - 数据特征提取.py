import os
import re
import pandas as pd
from Bio import SeqIO
from tkinter import Tk, simpledialog
from tkinter.filedialog import askdirectory
from tqdm import tqdm
import numpy as np

# 设置Tkinter不显示根窗口
Tk().withdraw()

# 弹出文件夹检索框
folder_path = askdirectory(title='Select Folder with FASTA files')

# 用户输入设置
min_bstr_length = int(simpledialog.askstring("Input", "Set minimum bSTR total length (bp):"))
min_motif_length = int(simpledialog.askstring("Input", "Set minimum motif length:"))
max_motif_length = int(simpledialog.askstring("Input", "Set maximum motif length:"))
min_repeats = int(simpledialog.askstring("Input", "Set minimum repeats:"))
max_repeats = int(simpledialog.askstring("Input", "Set maximum repeats:"))
vstr_threshold = float(simpledialog.askstring("Input", "Set vSTR threshold (%):"))


# 定义bSTR查找函数
def find_bstrs(sequence):
    bstrs = []
    for motif_length in range(min_motif_length, max_motif_length + 1):
        pattern = re.compile(r'((\w{%d})\2{%d,})' % (motif_length, min_repeats - 1))
        for match in pattern.finditer(sequence):
            motif = match.group(2)
            full_seq = match.group(1)
            start = match.start(1) + 1  # 修正STR Start数值
            end = match.end(1)
            repeats = len(full_seq) // len(motif)
            gc_content = (full_seq.count('G') + full_seq.count('C')) / len(full_seq) * 100
            at_content = (full_seq.count('A') + full_seq.count('T')) / len(full_seq) * 100
            if len(full_seq) >= min_bstr_length and min_repeats <= repeats <= max_repeats:
                bstrs.append({
                    'Sequence': full_seq,
                    'STR Start': start,
                    'STR End': end,
                    'Motif Length': len(motif),
                    'Repeats': repeats,
                    'Total Length': len(full_seq),
                    'GC Content (%)': gc_content,
                    'AT Content (%)': at_content
                })
    return bstrs


# 定义函数以判断变异形式
def classify_variation(ref_seq, var_seq):
    transitions = {'A': 'G', 'G': 'A', 'C': 'T', 'T': 'C'}
    transversions = {
        'A': ['C', 'T'],
        'C': ['A', 'G'],
        'G': ['C', 'T'],
        'T': ['A', 'G']
    }
    transition_count = 0
    transversion_count = 0

    for ref_base, var_base in zip(ref_seq, var_seq):
        if ref_base != var_base:
            if var_base == transitions.get(ref_base, ''):
                transition_count += 1
            elif var_base in transversions.get(ref_base, []):
                transversion_count += 1

    return transition_count, transversion_count


# 定义计算数值型基本特征函数
def calculate_features(vstrs, sequence_length):
    num_vstr = len(vstrs)
    motif_lengths = [vstr['Motif Length'] for vstr in vstrs]
    repeats_sizes = [vstr['Repeats'] for vstr in vstrs]
    total_lengths = [vstr['Total Length'] for vstr in vstrs]
    gc_contents = [vstr['GC Content (%)'] for vstr in vstrs]
    at_contents = [vstr['AT Content (%)'] for vstr in vstrs]

    motif_length_proportions = {}
    repeats_proportions = {}

    for length in range(min_motif_length, max_motif_length + 1):
        motif_length_proportions[f'Motif Length Proportion_{length}'] = (
                    motif_lengths.count(length) / num_vstr * 100) if num_vstr > 0 else 0

    for repeat in range(min_repeats, max_repeats + 1):
        repeats_proportions[f'Repeats Proportion_{repeat}'] = (
                    repeats_sizes.count(repeat) / num_vstr * 100) if num_vstr > 0 else 0

    gc_content_avg = np.mean(gc_contents) if gc_contents else 0
    at_content_avg = np.mean(at_contents) if at_contents else 0

    total_bstr_length = sum(total_lengths)
    vstr_length_density = (total_bstr_length * 100) / sequence_length if sequence_length > 0 else 0
    vstr_number_density = (num_vstr * 100) / sequence_length if sequence_length > 0 else 0

    features = {
        'vSTR Count': num_vstr,
        'Mean Motif Length': np.mean(motif_lengths) if motif_lengths else 0,
        'Mean Repeats Size': np.mean(repeats_sizes) if repeats_sizes else 0,
        'Mean Total Length': np.mean(total_lengths) if total_lengths else 0,
        'GC Content (%)': gc_content_avg,
        'AT Content (%)': at_content_avg,
        'vSTR Length relative density (%)': vstr_length_density,
        'vSTR Number relative density (units/bp)': vstr_number_density
    }

    features.update(motif_length_proportions)
    features.update(repeats_proportions)

    return features


# 遍历文件夹并处理所有FASTA文件
files = [f for f in os.listdir(folder_path) if f.endswith('.fas') or f.endswith('.fasta')]

for file in tqdm(files, desc="Processing files"):
    file_path = os.path.join(folder_path, file)
    results = []
    sequences = [record for record in SeqIO.parse(file_path, 'fasta')]
    for record in sequences:
        sequence = str(record.seq)  # 保留所有的gaps
        bstrs = find_bstrs(sequence)
        sequence_length = len(sequence)
        total_vstr_length = 0
        total_vstr_count = 0
        transition_count = 0
        transversion_count = 0
        vstrs = []

        for bstr in bstrs:
            start, end = bstr['STR Start'], bstr['STR End']
            bstr_seq = sequence[start - 1:end]
            differences = 0
            for other_record in sequences:
                if other_record.id != record.id:
                    other_seq = str(other_record.seq)
                    other_bstr_seq = other_seq[start - 1:end]
                    if other_bstr_seq != bstr_seq:
                        differences += 1
                        trans, transv = classify_variation(bstr_seq, other_bstr_seq)
                        transition_count += trans
                        transversion_count += transv
            if (differences / len(sequences)) * 100 >= vstr_threshold:
                bstr['is_vSTR'] = True
                vstrs.append(bstr)
                total_vstr_length += bstr['Total Length']
                total_vstr_count += 1
            else:
                bstr['is_vSTR'] = False

        features = calculate_features(vstrs, sequence_length)
        features.update({
            'Sequence ID': record.description,
            'Transition Count': transition_count,
            'Transversion Count': transversion_count,
            'Transition/Transversion Ratio': transition_count / transversion_count if transversion_count > 0 else 'NA',
            'vSTR Proportion (%)': (total_vstr_count / len(bstrs)) * 100 if len(bstrs) > 0 else 0
        })
        results.append(features)

    df = pd.DataFrame(results)

    # 添加平均值和标准差
    mean_row = df.mean(numeric_only=True)
    std_row = df.std(numeric_only=True)
    mean_row['Sequence ID'] = 'Average'
    std_row['Sequence ID'] = 'Standard Deviation'
    df = pd.concat([df, pd.DataFrame([mean_row, std_row])], ignore_index=True)

    # 重新排序列
    columns_order = ['Sequence ID', 'vSTR Count', 'Mean Motif Length', 'Mean Repeats Size', 'Mean Total Length'] + \
                    [col for col in df.columns if col.startswith('Motif Length Proportion')] + \
                    [col for col in df.columns if col.startswith('Repeats Proportion')] + \
                    ['GC Content (%)', 'AT Content (%)', 'vSTR Length relative density (%)',
                     'vSTR Number relative density (units/bp)', 'Transition Count', 'Transversion Count',
                     'Transition/Transversion Ratio', 'vSTR Proportion (%)']

    df = df[columns_order]

    excel_filename = f'vSTR_data_features-{os.path.splitext(file)[0]}.xlsx'
    df.to_excel(excel_filename, index=False)
    print(f"Results saved to {excel_filename}")

print("All results saved to respective Excel files")
